import numpy as np
import pandas as pd
import uuid

def generate_netflix_churn_dataset(n_rows=5000, seed=42):
    np.random.seed(seed)
    
    # 1. customer_id (UUIDs)
    customer_ids = [str(uuid.uuid4()) for _ in range(n_rows)]
    
    # 2. age: approx mean ~43.8, std ~15.5, bounds [18, 70]
    raw_age = np.random.normal(loc=43.8, scale=15.5, size=n_rows)
    age = np.clip(np.round(raw_age), 18, 70).astype(int)
    
    # 3. gender: 'Female' (~34%), 'Male' (~33%), 'Other' (~33%)
    gender = np.random.choice(['Female', 'Male', 'Other'], size=n_rows, p=[0.342, 0.330, 0.328])
    
    # 4. subscription_type: Basic, Standard, Premium
    sub_types = np.random.choice(['Basic', 'Standard', 'Premium'], size=n_rows, p=[0.33, 0.33, 0.34])
    
    # 5. monthly_fee linked directly to subscription type
    fee_map = {'Basic': 8.99, 'Standard': 13.99, 'Premium': 17.99}
    monthly_fee = np.array([fee_map[s] for s in sub_types])
    
    # 6. last_login_days: min 0, max 60, mean ~30
    last_login_days = np.random.randint(0, 61, size=n_rows)
    
    # 7. watch_hours: right-skewed lognormal distribution, mean ~11.6, median ~8.0, max ~110
    raw_watch = np.random.lognormal(mean=2.08, sigma=0.85, size=n_rows)
    watch_hours = np.round(np.clip(raw_watch, 0.01, 110.40), 2)
    
    # 8. avg_watch_time_per_day: correlated with watch_hours / 30, with some outliers
    avg_watch = np.round(np.clip(watch_hours / np.random.uniform(20, 35, size=n_rows) + np.random.exponential(scale=0.3, size=n_rows), 0.0, 98.42), 2)
    # add rare heavy-streamer outliers
    outlier_idx = np.random.choice(n_rows, size=15, replace=False)
    avg_watch[outlier_idx] = np.random.uniform(15.0, 98.42, size=15).round(2)
    
    # 9. region
    region = np.random.choice(['South America', 'North America', 'Europe', 'Asia', 'Africa', 'Oceania'], 
                              size=n_rows, p=[0.175, 0.17, 0.17, 0.17, 0.16, 0.155])
    
    # 10. device
    device = np.random.choice(['Tablet', 'TV', 'Mobile', 'Laptop', 'Desktop'], 
                              size=n_rows, p=[0.21, 0.20, 0.20, 0.20, 0.19])
    
    # 11. payment_method
    payment_method = np.random.choice(['Debit Card', 'Credit Card', 'PayPal', 'Gift Card', 'Crypto'], 
                                      size=n_rows, p=[0.21, 0.21, 0.20, 0.20, 0.18])
    
    # 12. number_of_profiles: 1 to 5
    number_of_profiles = np.random.choice([1, 2, 3, 4, 5], size=n_rows, p=[0.20, 0.20, 0.20, 0.20, 0.20])
    
    # 13. favorite_genre
    favorite_genre = np.random.choice(['Action', 'Sci-Fi', 'Drama', 'Horror', 'Romance', 'Comedy', 'Documentary'], 
                                      size=n_rows, p=[0.15, 0.15, 0.15, 0.14, 0.14, 0.14, 0.13])
    
    # 14. churned calculation with realistic behavioral weighting:
    # High last_login_days -> increases churn
    # Low watch_hours -> increases churn
    # Higher monthly fee with 1 profile (high fee_per_profile) -> increases churn
    # Risky payment methods (Crypto, Gift Card) -> slightly higher churn
    fee_per_prof = monthly_fee / number_of_profiles
    
    logit = (
        0.055 * (last_login_days - 30.0) 
        - 0.08 * (watch_hours - 11.6)
        + 0.12 * (fee_per_prof - 5.0)
        + 0.015 * (age - 44.0)
        + (payment_method == 'Crypto') * 0.40
        + (payment_method == 'Gift Card') * 0.30
        - (sub_types == 'Standard') * 0.15
        - 0.05
    )
    
    prob = 1 / (1 + np.exp(-logit))
    churned = (np.random.rand(n_rows) < prob).astype(int)
    
    df = pd.DataFrame({
        'customer_id': customer_ids,
        'age': age,
        'gender': gender,
        'subscription_type': sub_types,
        'watch_hours': watch_hours,
        'last_login_days': last_login_days,
        'region': region,
        'device': device,
        'monthly_fee': monthly_fee,
        'churned': churned,
        'payment_method': payment_method,
        'number_of_profiles': number_of_profiles,
        'avg_watch_time_per_day': avg_watch,
        'favorite_genre': favorite_genre
    })
    
    return df

if __name__ == '__main__':
    df = generate_netflix_churn_dataset(5000, seed=42)
    df.to_csv('data/netflix_customer_churn_dataset.csv', index=False)
    # Also save a 100-row sample for quick download & tests
    df.head(100).to_csv('data/sample_dataset.csv', index=False)
    print("Dataset generated successfully!")
    print("Shape:", df.shape)
    print("Churn rate:", df['churned'].mean())
    print("Columns:", df.columns.tolist())
    print("\nSummary Stats:\n", df.describe())
