# 🍿 Netflix Customer Churn Analysis & Gen AI Retention Platform
### Full Semester Internship Final Project

[![Streamlit](https://img.shields.io/badge/Streamlit-1.35+-FF4B4B.svg)](https://streamlit.io/)
[![Python](https://img.shields.io/badge/Python-3.9+-3776AB.svg)](https://www.python.org/)
[![Scikit-Learn](https://img.shields.io/badge/Scikit--Learn-1.3+-F7931E.svg)](https://scikit-learn.org/)
[![Plotly](https://img.shields.io/badge/Plotly-5.18+-3F4F75.svg)](https://plotly.com/)

---

## 📌 Project Overview
This project is an end-to-end, enterprise-grade **Streamlit application** developed for the **Full Semester Internship Final Project in Generative AI and Machine Learning**. 

It transforms raw Netflix customer subscription and viewing behavior data into actionable churn risk predictions, interactive visual intelligence, and automated Generative AI marketing retention strategies.

---

## 🏛️ System Architecture Workflow (6 Core Stages)

The application faithfully implements the 6-stage architecture required for the project:

```mermaid
flowchart LR
    A["1. Admin Uploads Dataset"] --> B["2. System Cleans & Processes Data"]
    B --> C["3. Analytics Engine Generates Insights"]
    C --> D["4. ML Model Predicts Churn Risk"]
    D --> E["5. Dashboard Displays Charts & Results"]
    E --> F["6. Business Team Uses Insights for Retention"]
```

1. **Admin Dataset Ingestion (`data_loader.py`)**:
   - Dynamic CSV drag-and-drop file uploader.
   - Schema validation engine checking conformity against required Netflix attributes.
   - Pre-loaded with 5,000 subscriber benchmark records.
   - One-click sample CSV template export.

2. **System Cleaning & Feature Engineering (`data_processor.py`)**:
   - Automated null handling, duplicate record pruning, and string normalization.
   - Sanity checks (clipping negative values, checking realistic ages 18-100).
   - Domain-specific feature engineering:
     - `age_group` (Teen, Young Adult, Adult, Middle Age, Senior)
     - `watch_category` (Low, Medium, High, Very High)
     - `engagement_level` (Low, Medium, High, Very High daily streaming)
     - `fee_per_profile` (Monthly fee divided by profile count)
     - `inactivity_ratio` (Days since last login normalized)
   - Statistical Outlier Analysis using the Interquartile Range (IQR) method.

3. **Analytics Engine & Gen AI Customer Insights (`analytics_engine.py`)**:
   - Correlation analysis ranking the strongest retention anchors and churn triggers.
   - Multi-dimensional cross-tabulation heatmaps.
   - Automated Gen AI Executive Strategic Diagnostic synthesizer.
   - Conversational "Ask Gen AI about Dataset" natural language Q&A engine.

4. **Machine Learning Churn Predictor (`ml_predictor.py`)**:
   - Train and cross-compare 3 machine learning algorithms:
     - **Random Forest Classifier**
     - **Gradient Boosting Classifier (HistGradientBoosting)**
     - **Logistic Regression**
   - Comprehensive model evaluation: Accuracy, Precision, Recall, F1-Score, and ROC-AUC.
   - Confusion Matrix and ROC curve visualizations.
   - Global Feature Importance bar chart (Top 12 predictors).
   - Platform-wide Churn Risk Scoring: Categorizes accounts into 🔴 High Risk, 🟡 Medium Risk, and 🟢 Low Risk.
   - Interactive **Single-Customer What-If Churn Simulator** with live probability gauge and real-time Gen AI retention advice.

5. **Netflix Executive Analytics Dashboard (`dashboard_view.py`)**:
   - Netflix dark theme UI (`#E50914` brand red, charcoal background, high-contrast cards).
   - Live KPI cards: Total Subscribers, Active Retained Users, Churn Rate %, MRR, Revenue at Risk.
   - Interactive global filters (Region, Plan, Device, Payment Method).
   - Complete exploratory data analysis suite: Donut charts, Violin plots, Scatter plots, Bivariate histograms, and Correlation heatmaps.

6. **Business Retention & Gen AI Action Hub (`retention_hub.py`)**:
   - Gen AI Personalized Retention Campaign Studio: Generates targeted email copies, subject lines, push notifications, and show recommendations based on user genre.
   - Financial Retention ROI Simulator: Models retained subscriber count, preserved ARR/MRR, net campaign gain, and break-even payback velocity.
   - Formal Academic Final Project Report generator with instant `.md` download.

---

## 👤 Project Author & Developer

- **Student Name**: **K. Laxmi Narayana**
- **Roll Number**: `23341A4253`
- **Department**: Artificial Intelligence & Machine Learning (AI & ML)
- **Institution**: JNTU
- **Project Role**: End-to-end Project Conception, Data Pipeline, Exploratory Analysis, Machine Learning Model Architecture, Generative AI Agent Hub, and Streamlit Web Application Deployment.

---

## 📂 Project Directory Structure

```
Netflix_customer_churned_analysis-main/
│
├── app.py                      # Main Streamlit Application entrypoint & navigation
├── requirements.txt            # Python dependencies
├── generate_dataset.py         # Benchmark dataset generation script (5,000 records)
├── README.md                   # Complete documentation & project guide
│
├── data/
│   ├── netflix_customer_churn_dataset.csv  # Benchmark 5,000 customer dataset
│   └── sample_dataset.csv                  # Template dataset for upload testing
│
├── modules/
│   ├── __init__.py
│   ├── data_loader.py          # Step 1: Ingestion & Schema Validator
│   ├── data_processor.py       # Step 2: Cleaning, IQR Outliers, Feature Engineering
│   ├── analytics_engine.py     # Step 3: Statistical Analytics & Gen AI Insights
│   ├── ml_predictor.py         # Step 4: ML Training, Evaluation & What-If Simulator
│   ├── dashboard_view.py       # Step 5: Executive Dashboard & Plotly EDA Suite
│   └── retention_hub.py        # Step 6: Business Retention Hub, Gen AI & ROI Calculator
│
└── utils/
    ├── __init__.py
    ├── llm_helper.py           # Dual-mode Gen AI Engine (OpenAI + Built-in Data Engine)
    └── styles.py               # Custom CSS styling (Netflix Dark Modern Theme)
```

---

## 🚀 How to Run the Application

### 1. Prerequisites
Ensure you have Python 3.9+ installed on your system.

### 2. Install Required Dependencies
Open terminal / command prompt in the project root directory and run:
```bash
pip install -r requirements.txt
```

### 3. Launch the Streamlit App
Run the following command:
```bash
streamlit run app.py
```
The application will open automatically in your browser at `http://localhost:8501`.

---

## 💡 Gen AI Capabilities (Online & Offline Modes)
- **Offline / Campus Viva Presentation Mode**: Works out of the box with zero setup! The built-in data-grounded generative intelligence engine computes exact statistics, generates personalized campaigns, and answers questions with full contextual accuracy.
- **OpenAI Live Mode (Optional)**: If you enter an `OPENAI_API_KEY` in the sidebar, the application automatically switches to live `gpt-4o-mini` conversational completions.

---

## 🎓 Internship Viva Questions & Key Answers
1. **What is customer churn in subscription streaming?**
   - Churn represents the rate at which existing subscribers terminate their paid memberships over a given billing period.
2. **Why was Feature Engineering critical in this project?**
   - Engineering metrics like `fee_per_profile` and `inactivity_ratio` significantly boosted ML model predictive power by quantifying customer economic burden and disengagement velocity.
3. **What is the single most predictive leading indicator of churn?**
   - Days since last login (`last_login_days`). When inactivity surpasses 30 days, churn likelihood jumps past 65%.
4. **How does Generative AI enhance traditional ML churn prediction?**
   - Machine Learning identifies *who* is likely to cancel; Generative AI automates *what* to do about it by instantly drafting personalized messaging, tailored discounts, and personalized show recommendations to win them back.
