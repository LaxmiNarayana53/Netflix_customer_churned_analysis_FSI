@echo off
title Netflix Customer Churn Analysis - Gen AI Internship Project
echo =====================================================================
echo  NETFLIX CUSTOMER CHURN ANALYSIS & GEN AI RETENTION PLATFORM
echo  Full Semester Internship Final Project
echo =====================================================================
echo.
echo Launching Streamlit application...
python -m streamlit run app.py
pause
