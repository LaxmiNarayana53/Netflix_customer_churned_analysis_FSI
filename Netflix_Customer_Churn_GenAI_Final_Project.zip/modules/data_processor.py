"""
Module 2: System Cleans and Processes Data
Performs automated data cleaning, validation checks, feature engineering, and IQR outlier detection.
"""

import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
from utils.styles import get_chart_theme

def clean_and_process_data(df_raw: pd.DataFrame) -> (pd.DataFrame, dict):
    """
    Automated data cleaning and feature engineering pipeline matching the team's project specifications.
    """
    df = df_raw.copy()
    logs = {}
    
    # 1. Missing values
    missing_before = int(df.isnull().sum().sum())
    # Fill numeric nulls with median, categorical with mode
    for col in df.select_dtypes(include='number').columns:
        if df[col].isnull().any():
            df[col] = df[col].fillna(df[col].median())
    for col in df.select_dtypes(include=['object', 'category']).columns:
        if df[col].isnull().any():
            df[col] = df[col].fillna(df[col].mode()[0])
    logs['missing_resolved'] = missing_before
    
    # 2. Duplicate records
    dupes_before = int(df.duplicated().sum())
    df = df.drop_duplicates()
    logs['duplicates_removed'] = dupes_before
    
    # 3. Standardize column names
    df.columns = (
        df.columns
        .str.strip()
        .str.lower()
        .str.replace(" ", "_")
    )
    
    # 4. Standardize categorical text
    cat_cols = df.select_dtypes(include="object").columns
    for c in cat_cols:
        if c != 'customer_id':
            df[c] = df[c].astype(str).str.strip().str.title()
    logs['categoricals_standardized'] = len(cat_cols)
    
    # 5. Sanity checks (clip negatives and unrealistic ages)
    num_cols = ['age', 'watch_hours', 'last_login_days', 'monthly_fee', 'number_of_profiles', 'avg_watch_time_per_day']
    for c in num_cols:
        if c in df.columns:
            df[c] = df[c].clip(lower=0)
    if 'age' in df.columns:
        df['age'] = df['age'].clip(18, 100)
        
    # 6. Feature Engineering (Exact specifications from notebook)
    # 6.1 Age Group
    if 'age' in df.columns:
        df["age_group"] = pd.cut(
            df["age"],
            bins=[0, 18, 30, 45, 60, 100],
            labels=["Teen", "Young Adult", "Adult", "Middle Age", "Senior"]
        )
        
    # 6.2 Watch Category
    if 'watch_hours' in df.columns:
        df["watch_category"] = pd.cut(
            df["watch_hours"],
            bins=[-np.inf, 20, 40, 60, np.inf],
            labels=["Low", "Medium", "High", "Very High"]
        )
        
    # 6.3 Engagement Level
    if 'avg_watch_time_per_day' in df.columns:
        df["engagement_level"] = pd.cut(
            df["avg_watch_time_per_day"],
            bins=[-np.inf, 1, 2, 4, np.inf],
            labels=["Low", "Medium", "High", "Very High"]
        )
        
    # 6.4 Fee Per Profile
    if 'monthly_fee' in df.columns and 'number_of_profiles' in df.columns:
        df["fee_per_profile"] = (df["monthly_fee"] / df["number_of_profiles"].replace(0, 1)).round(2)
        
    # 6.5 Inactivity Ratio (0 to 1 scale across 60 days)
    if 'last_login_days' in df.columns:
        df["inactivity_ratio"] = (df["last_login_days"] / 60.0).round(3)
        
    # 6.6 Subscription Group
    if 'subscription_type' in df.columns:
        df["subscription_group"] = df["subscription_type"]

    return df, logs


def calculate_iqr_outliers(df: pd.DataFrame, num_cols: list) -> pd.DataFrame:
    """
    Calculates IQR outlier statistics for numerical features.
    """
    records = []
    for col in num_cols:
        if col in df.columns:
            q1 = df[col].quantile(0.25)
            q3 = df[col].quantile(0.75)
            iqr = q3 - q1
            lower_bound = q1 - 1.5 * iqr
            upper_bound = q3 + 1.5 * iqr
            outliers = df[(df[col] < lower_bound) | (df[col] > upper_bound)]
            records.append({
                'Feature': col,
                'Q1 (25%)': round(q1, 2),
                'Median (50%)': round(df[col].median(), 2),
                'Q3 (75%)': round(q3, 2),
                'IQR': round(iqr, 2),
                'Lower Bound': round(lower_bound, 2),
                'Upper Bound': round(upper_bound, 2),
                'Outlier Count': len(outliers),
                'Outlier %': f"{(len(outliers) / len(df)) * 100:.2f}%"
            })
    return pd.DataFrame(records)


def render_data_processor():
    st.markdown('<div class="netflix-brand">Step 2: System Data Processing & Feature Engineering</div>', unsafe_allow_html=True)
    st.markdown(
        '<div class="netflix-subhead">Automated data cleaning, categorical normalization, derived metrics, and IQR outlier analysis.</div>',
        unsafe_allow_html=True
    )
    
    raw_df = st.session_state.get('raw_df')
    if raw_df is None:
        st.warning("⚠️ No dataset available. Please visit **'1. Admin Dataset Ingestion'** to upload or load data.")
        return
        
    # Trigger Cleaning Pipeline
    col_btn, col_info = st.columns([1, 2])
    with col_btn:
        run_clean = st.button("🚀 Run Automated Pipeline", use_container_width=True)
        
    # Automatically execute cleaning if not already in session state
    if run_clean or ('processed_df' not in st.session_state):
        with st.spinner("Processing data, engineering features, and running validation checks..."):
            processed_df, logs = clean_and_process_data(raw_df)
            st.session_state['processed_df'] = processed_df
            st.session_state['clean_logs'] = logs
            if run_clean:
                st.success(" Pipeline executed successfully!")
                
    df = st.session_state['processed_df']
    logs = st.session_state.get('clean_logs', {})
    
    # Cleaning Results Badges
    st.markdown("### 🛠️ Data Cleaning Audit Trail")
    c1, c2, c3, c4 = st.columns(4)
    with c1:
        st.markdown(
            f"""<div class="metric-card">
                <div class="metric-title">Missing Values Resolved</div>
                <div class="metric-value">{logs.get('missing_resolved', 0)}</div>
                <div class="metric-delta delta-success">Zero Nulls Remaining</div>
            </div>""", unsafe_allow_html=True
        )
    with c2:
        st.markdown(
            f"""<div class="metric-card">
                <div class="metric-title">Duplicates Pruned</div>
                <div class="metric-value">{logs.get('duplicates_removed', 0)}</div>
                <div class="metric-delta delta-success">100% Unique Accounts</div>
            </div>""", unsafe_allow_html=True
        )
    with c3:
        st.markdown(
            f"""<div class="metric-card">
                <div class="metric-title">Categoricals Standardized</div>
                <div class="metric-value">{logs.get('categoricals_standardized', 0)}</div>
                <div class="metric-delta">Title Cased & Stripped</div>
            </div>""", unsafe_allow_html=True
        )
    with c4:
        new_features = len(df.columns) - len(raw_df.columns)
        st.markdown(
            f"""<div class="metric-card">
                <div class="metric-title">Engineered Features</div>
                <div class="metric-value">+{new_features}</div>
                <div class="metric-delta delta-warning">High-Signal Indicators</div>
            </div>""", unsafe_allow_html=True
        )

    # Feature Engineering Showcase
    st.markdown("---")
    st.markdown("### 🧩 Engineered Features Breakdown")
    
    feat_tabs = st.tabs([
        "👶 Age Groups", 
        "⏳ Watch Category", 
        "⚡ Engagement Level", 
        "💳 Fee Per Profile", 
        "📦 Complete Processed Dataset"
    ])
    
    with feat_tabs[0]:
        st.write("**`age_group`**: Segmenting subscribers into behavioral life stages (`Teen`, `Young Adult`, `Adult`, `Middle Age`, `Senior`).")
        if 'age_group' in df.columns:
            age_summary = df.groupby('age_group', observed=False).agg({
                'customer_id': 'count',
                'watch_hours': 'mean',
                'last_login_days': 'mean',
                'churned': 'mean'
            }).reset_index()
            age_summary.columns = ['age_group', 'Subscribers', 'Avg_Watch_Hours', 'Avg_Last_Login', 'Churn_Rate']
            age_summary['Churn_Rate'] = (age_summary['Churn_Rate'] * 100).round(1).astype(str) + '%'
            age_summary['Avg_Watch_Hours'] = age_summary['Avg_Watch_Hours'].round(1)
            age_summary['Avg_Last_Login'] = age_summary['Avg_Last_Login'].round(1)
            st.dataframe(age_summary, use_container_width=True)
            
    with feat_tabs[1]:
        st.write("**`watch_category`**: Binned monthly streaming hours (`Low` <=20h, `Medium` 21-40h, `High` 41-60h, `Very High` >60h).")
        if 'watch_category' in df.columns:
            watch_summary = df.groupby('watch_category', observed=False).agg({
                'customer_id': 'count',
                'monthly_fee': 'mean',
                'churned': 'mean'
            }).reset_index()
            watch_summary.columns = ['watch_category', 'Subscribers', 'Avg_Monthly_Fee', 'Churn_Rate']
            watch_summary['Churn_Rate'] = (watch_summary['Churn_Rate'] * 100).round(1).astype(str) + '%'
            watch_summary['Avg_Monthly_Fee'] = '$' + watch_summary['Avg_Monthly_Fee'].round(2).astype(str)
            st.dataframe(watch_summary, use_container_width=True)

    with feat_tabs[2]:
        st.write("**`engagement_level`**: Average streaming hours per day (`Low` <=1h, `Medium` 1-2h, `High` 2-4h, `Very High` >4h).")
        if 'engagement_level' in df.columns:
            eng_summary = df.groupby('engagement_level', observed=False).agg({
                'customer_id': 'count',
                'last_login_days': 'mean',
                'churned': 'mean'
            }).reset_index()
            eng_summary.columns = ['engagement_level', 'Subscribers', 'Avg_Inactivity_Days', 'Churn_Rate']
            eng_summary['Churn_Rate'] = (eng_summary['Churn_Rate'] * 100).round(1).astype(str) + '%'
            eng_summary['Avg_Inactivity_Days'] = eng_summary['Avg_Inactivity_Days'].round(1)
            st.dataframe(eng_summary, use_container_width=True)

    with feat_tabs[3]:
        st.write("**`fee_per_profile`**: Monthly cost divided by number of authorized streaming profiles (`monthly_fee / number_of_profiles`).")
        if 'fee_per_profile' in df.columns:
            cols_preview = ['customer_id', 'subscription_type', 'monthly_fee', 'number_of_profiles', 'fee_per_profile', 'churned']
            st.dataframe(df[cols_preview].head(8), use_container_width=True)

    with feat_tabs[4]:
        st.dataframe(df.head(10), use_container_width=True)
        csv_data = df.to_csv(index=False).encode('utf-8')
        st.download_button(
            label="⬇️ Download Cleaned & Engineered Dataset (CSV)",
            data=csv_data,
            file_name="netflix_churn_cleaned_processed.csv",
            mime="text/csv"
        )

    # Outlier Analysis & IQR Detection
    st.markdown("---")
    st.markdown("### 🔬 Statistical Outlier Analysis (IQR Method)")
    st.markdown(
        "Outliers detected using the standard Interquartile Range method: "
        r"$\text{IQR} = Q_3 - Q_1$, with bounds $[\,Q_1 - 1.5\times\text{IQR},\; Q_3 + 1.5\times\text{IQR}\,]$."
    )
    
    num_cols_for_iqr = ['age', 'watch_hours', 'last_login_days', 'monthly_fee', 'number_of_profiles', 'avg_watch_time_per_day']
    iqr_df = calculate_iqr_outliers(df, num_cols_for_iqr)
    st.dataframe(iqr_df, use_container_width=True)
    
    # Interactive Box Plot for Outlier Inspection
    col_sel, col_chart = st.columns([1, 2])
    with col_sel:
        selected_iqr_col = st.selectbox("Inspect Feature Distribution & Outliers:", num_cols_for_iqr, index=1)
        st.info(f"Visualizing box plot & jittered observations for `{selected_iqr_col}`.")
    with col_chart:
        fig_box = px.box(
            df, 
            y=selected_iqr_col, 
            color='churned',
            color_discrete_map={0: '#46D369', 1: '#E50914'},
            labels={'churned': 'Churn Status (1=Yes, 0=No)'},
            title=f"Box Plot: {selected_iqr_col} by Churn Status",
            template='plotly_dark'
        )
        fig_box.update_layout(height=350, margin=dict(l=20, r=20, t=40, b=20))
        st.plotly_chart(fig_box, use_container_width=True)
        
    st.info("💡 Next Step: Click on **'3. Analytics & GenAI Insights'** to run the statistical engine and generate AI-driven churn diagnostics.")
