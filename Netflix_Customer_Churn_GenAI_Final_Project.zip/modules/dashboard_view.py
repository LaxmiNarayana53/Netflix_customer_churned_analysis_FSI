"""
Module 5: Executive Dashboard Displays Charts and Results
Interactive Netflix dark-themed visual command center with KPIs and complete EDA visualizations.
"""

import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from utils.styles import get_chart_theme

def render_dashboard():
    st.markdown('<div class="netflix-brand">Step 5: Netflix Executive Analytics Dashboard</div>', unsafe_allow_html=True)
    st.markdown(
        '<div class="netflix-subhead">Holistic command center tracking subscriber retention health, behavioral streaming metrics, and revenue risks.</div>',
        unsafe_allow_html=True
    )
    
    df = st.session_state.get('processed_df')
    if df is None:
        st.warning("⚠️ No dataset available. Please complete previous steps first.")
        return
        
    # Global Interactive Filters
    st.markdown("### 🎚️ Global Interactive Filters")
    f_col1, f_col2, f_col3, f_col4 = st.columns(4)
    
    with f_col1:
        regions = ['All Regions'] + sorted(df['region'].dropna().unique().tolist()) if 'region' in df.columns else ['All']
        sel_region = st.selectbox("Region Filter:", regions)
        
    with f_col2:
        subs = ['All Tiers'] + sorted(df['subscription_type'].dropna().unique().tolist()) if 'subscription_type' in df.columns else ['All']
        sel_sub = st.selectbox("Subscription Tier:", subs)
        
    with f_col3:
        devices = ['All Devices'] + sorted(df['device'].dropna().unique().tolist()) if 'device' in df.columns else ['All']
        sel_device = st.selectbox("Device Filter:", devices)
        
    with f_col4:
        payments = ['All Methods'] + sorted(df['payment_method'].dropna().unique().tolist()) if 'payment_method' in df.columns else ['All']
        sel_payment = st.selectbox("Payment Method:", payments)

    # Apply filters
    filtered_df = df.copy()
    if sel_region != 'All Regions' and 'region' in filtered_df.columns:
        filtered_df = filtered_df[filtered_df['region'] == sel_region]
    if sel_sub != 'All Tiers' and 'subscription_type' in filtered_df.columns:
        filtered_df = filtered_df[filtered_df['subscription_type'] == sel_sub]
    if sel_device != 'All Devices' and 'device' in filtered_df.columns:
        filtered_df = filtered_df[filtered_df['device'] == sel_device]
    if sel_payment != 'All Methods' and 'payment_method' in filtered_df.columns:
        filtered_df = filtered_df[filtered_df['payment_method'] == sel_payment]

    if filtered_df.empty:
        st.warning("No records match the selected filter combination. Resetting to full dataset.")
        filtered_df = df.copy()

    # Executive KPI Cards
    st.markdown("---")
    st.markdown("### 📌 Executive Retention KPIs")
    k1, k2, k3, k4, k5 = st.columns(5)
    
    total_sub = len(filtered_df)
    churn_cnt = int(filtered_df['churned'].sum())
    active_cnt = total_sub - churn_cnt
    churn_rate = (churn_cnt / total_sub) * 100 if total_sub > 0 else 0
    total_mrr = filtered_df['monthly_fee'].sum()
    risk_mrr = filtered_df[filtered_df['churned'] == 1]['monthly_fee'].sum()
    
    with k1:
        st.markdown(
            f"""<div class="metric-card">
                <div class="metric-title">Total Subscribers</div>
                <div class="metric-value">{total_sub:,}</div>
                <div class="metric-delta delta-success">Active Cohort</div>
            </div>""", unsafe_allow_html=True
        )
    with k2:
        st.markdown(
            f"""<div class="metric-card">
                <div class="metric-title">Retained Users</div>
                <div class="metric-value">{active_cnt:,}</div>
                <div class="metric-delta delta-success">{100 - churn_rate:.1f}% Loyal</div>
            </div>""", unsafe_allow_html=True
        )
    with k3:
        st.markdown(
            f"""<div class="metric-card">
                <div class="metric-title">Churned Users</div>
                <div class="metric-value">{churn_cnt:,}</div>
                <div class="metric-delta delta-danger">{churn_rate:.1f}% Churn Rate</div>
            </div>""", unsafe_allow_html=True
        )
    with k4:
        st.markdown(
            f"""<div class="metric-card">
                <div class="metric-title">Monthly Run-Rate (MRR)</div>
                <div class="metric-value">${total_mrr:,.0f}</div>
                <div class="metric-delta">Gross Billing</div>
            </div>""", unsafe_allow_html=True
        )
    with k5:
        st.markdown(
            f"""<div class="metric-card">
                <div class="metric-title">MRR at Churn Risk</div>
                <div class="metric-value">${risk_mrr:,.0f}</div>
                <div class="metric-delta delta-danger">${risk_mrr * 12:,.0f} / year</div>
            </div>""", unsafe_allow_html=True
        )

    # Visualization Grid
    st.markdown("---")
    st.markdown("### 📊 Exploratory Visual Analytics (EDA Suite)")
    
    dash_tabs = st.tabs([
        "🍩 Churn & Demographics", 
        "⏱️ Streaming & Behavior", 
        "💳 Billing & Revenue", 
        "🔥 Correlation Matrix"
    ])
    
    # TAB 1: Churn & Demographics
    with dash_tabs[0]:
        c1_1, c1_2 = st.columns(2)
        with c1_1:
            # Donut chart
            fig_donut = px.pie(
                filtered_df,
                names='churned',
                title="Subscriber Churn Distribution",
                hole=0.6,
                color='churned',
                color_discrete_map={0: '#46D369', 1: '#E50914'},
                template='plotly_dark'
            )
            fig_donut.update_traces(
                textposition='inside',
                textinfo='percent+label',
                labels=['Retained (0)', 'Churned (1)']
            )
            fig_donut.update_layout(height=380, margin=dict(l=20, r=20, t=40, b=20))
            st.plotly_chart(fig_donut, use_container_width=True)
            
        with c1_2:
            # Churn by Age Group
            if 'age_group' in filtered_df.columns:
                age_churn = filtered_df.groupby('age_group', observed=False)['churned'].mean().reset_index()
                age_churn['Churn Rate (%)'] = (age_churn['churned'] * 100).round(1)
                
                fig_age = px.bar(
                    age_churn,
                    x='age_group',
                    y='Churn Rate (%)',
                    color='Churn Rate (%)',
                    color_continuous_scale='Reds',
                    title="Customer Churn Rate by Age Group",
                    template='plotly_dark',
                    text_auto=True
                )
                fig_age.update_layout(height=380, margin=dict(l=20, r=20, t=40, b=20))
                st.plotly_chart(fig_age, use_container_width=True)

        c1_3, c1_4 = st.columns(2)
        with c1_3:
            # Churn by Gender
            if 'gender' in filtered_df.columns:
                fig_gender = px.histogram(
                    filtered_df,
                    x='gender',
                    color='churned',
                    barmode='group',
                    color_discrete_map={0: '#46D369', 1: '#E50914'},
                    labels={'churned': 'Churn Status'},
                    title="Customer Churn Count by Gender",
                    template='plotly_dark'
                )
                fig_gender.update_layout(height=380, margin=dict(l=20, r=20, t=40, b=20))
                st.plotly_chart(fig_gender, use_container_width=True)
                
        with c1_4:
            # Churn by Region
            if 'region' in filtered_df.columns:
                fig_reg = px.histogram(
                    filtered_df,
                    x='region',
                    color='churned',
                    barmode='group',
                    color_discrete_map={0: '#46D369', 1: '#E50914'},
                    labels={'churned': 'Churn Status'},
                    title="Customer Churn by Geographic Region",
                    template='plotly_dark'
                )
                fig_reg.update_layout(height=380, margin=dict(l=20, r=20, t=40, b=20))
                st.plotly_chart(fig_reg, use_container_width=True)

    # TAB 2: Streaming & Behavior
    with dash_tabs[1]:
        c2_1, c2_2 = st.columns(2)
        with c2_1:
            # Violin plot of watch hours by churn
            fig_viol = px.violin(
                filtered_df,
                y='watch_hours',
                x='churned',
                color='churned',
                box=True,
                points="all",
                color_discrete_map={0: '#46D369', 1: '#E50914'},
                title="Watch Hours Distribution by Churn Status (Violin Plot)",
                template='plotly_dark'
            )
            fig_viol.update_layout(height=400, margin=dict(l=20, r=20, t=40, b=20))
            st.plotly_chart(fig_viol, use_container_width=True)
            
        with c2_2:
            # Scatter Plot: Watch Hours vs Monthly Fee
            fig_scat = px.scatter(
                filtered_df,
                x='watch_hours',
                y='monthly_fee',
                color='churned',
                color_discrete_map={0: '#46D369', 1: '#E50914'},
                title="Watch Hours vs Monthly Fee (Colored by Churn)",
                template='plotly_dark',
                opacity=0.7
            )
            fig_scat.update_layout(height=400, margin=dict(l=20, r=20, t=40, b=20))
            st.plotly_chart(fig_scat, use_container_width=True)

        c2_3, c2_4 = st.columns(2)
        with c2_3:
            # Inactivity Distribution
            fig_hist = px.histogram(
                filtered_df,
                x='last_login_days',
                color='churned',
                nbins=30,
                color_discrete_map={0: '#46D369', 1: '#E50914'},
                title="Days Since Last Login Distribution",
                template='plotly_dark'
            )
            fig_hist.update_layout(height=380, margin=dict(l=20, r=20, t=40, b=20))
            st.plotly_chart(fig_hist, use_container_width=True)
            
        with c2_4:
            # Genre Analysis: Avg daily watch time by genre
            if 'favorite_genre' in filtered_df.columns:
                genre_df = filtered_df.groupby('favorite_genre')['avg_watch_time_per_day'].mean().reset_index()
                fig_genre = px.bar(
                    genre_df,
                    x='favorite_genre',
                    y='avg_watch_time_per_day',
                    color='avg_watch_time_per_day',
                    color_continuous_scale='Reds',
                    title="Average Daily Watch Time by Favorite Genre (hrs/day)",
                    template='plotly_dark',
                    text_auto=".2f"
                )
                fig_genre.update_layout(height=380, margin=dict(l=20, r=20, t=40, b=20))
                st.plotly_chart(fig_genre, use_container_width=True)

    # TAB 3: Billing & Revenue
    with dash_tabs[2]:
        c3_1, c3_2 = st.columns(2)
        with c3_1:
            # Revenue by subscription tier pie
            rev_sub = filtered_df.groupby('subscription_type')['monthly_fee'].sum().reset_index()
            fig_rev = px.pie(
                rev_sub,
                names='subscription_type',
                values='monthly_fee',
                title="Revenue Contribution by Subscription Tier",
                color_discrete_sequence=['#E50914', '#FFA00A', '#46D369'],
                template='plotly_dark',
                hole=0.4
            )
            fig_rev.update_layout(height=380, margin=dict(l=20, r=20, t=40, b=20))
            st.plotly_chart(fig_rev, use_container_width=True)
            
        with c3_2:
            if 'payment_method' in filtered_df.columns:
                pay_churn = filtered_df.groupby('payment_method')['churned'].agg(['count', 'mean']).reset_index()
                pay_churn.columns = ['payment_method', 'Total', 'Churn_Rate']
                pay_churn['Churn_Rate_%'] = (pay_churn['Churn_Rate'] * 100).round(1)
                
                fig_pay = px.bar(
                    pay_churn,
                    x='payment_method',
                    y='Churn_Rate_%',
                    color='Churn_Rate_%',
                    color_continuous_scale='Reds',
                    title="Customer Churn Rate by Payment Method (%)",
                    template='plotly_dark',
                    text_auto=True
                )
                fig_pay.update_layout(height=380, margin=dict(l=20, r=20, t=40, b=20))
                st.plotly_chart(fig_pay, use_container_width=True)

        c3_3, c3_4 = st.columns(2)
        with c3_3:
            # Device Churn Breakdown
            if 'device' in filtered_df.columns:
                fig_dev = px.histogram(
                    filtered_df,
                    x='device',
                    color='churned',
                    barmode='group',
                    color_discrete_map={0: '#46D369', 1: '#E50914'},
                    title="Subscriber Volume & Churn by Streaming Device",
                    template='plotly_dark'
                )
                fig_dev.update_layout(height=380, margin=dict(l=20, r=20, t=40, b=20))
                st.plotly_chart(fig_dev, use_container_width=True)
                
        with c3_4:
            # Fee Per Profile Boxplot
            if 'fee_per_profile' in filtered_df.columns:
                fig_fee = px.box(
                    filtered_df,
                    x='subscription_type',
                    y='fee_per_profile',
                    color='churned',
                    color_discrete_map={0: '#46D369', 1: '#E50914'},
                    title="Monthly Fee per Profile by Subscription Tier",
                    template='plotly_dark'
                )
                fig_fee.update_layout(height=380, margin=dict(l=20, r=20, t=40, b=20))
                st.plotly_chart(fig_fee, use_container_width=True)

    # TAB 4: Correlation Matrix
    with dash_tabs[3]:
        st.markdown("### 🔥 Numerical Feature Correlation Heatmap")
        num_cols = filtered_df.select_dtypes(include='number')
        corr_matrix = num_cols.corr()
        
        fig_heat = px.imshow(
            corr_matrix,
            text_auto=".2f",
            color_continuous_scale="RdBu_r",
            title="Correlation Heatmap across All Numerical Features",
            template='plotly_dark',
            zmin=-1,
            zmax=1
        )
        fig_heat.update_layout(height=520, margin=dict(l=20, r=20, t=40, b=20))
        st.plotly_chart(fig_heat, use_container_width=True)

    st.info("💡 Next Step: Click on **'6. Retention & Action Hub'** to generate personalized Gen AI retention campaigns and compute ROI.")
