"""
Module 1: Admin Dataset Upload & Ingestion
Allows admins to upload CSV datasets, validate schema, view summaries, and inspect raw records.
"""

import streamlit as st
import pandas as pd
import os

EXPECTED_COLUMNS = [
    'customer_id', 'age', 'gender', 'subscription_type', 'watch_hours',
    'last_login_days', 'region', 'device', 'monthly_fee', 'churned',
    'payment_method', 'number_of_profiles', 'avg_watch_time_per_day', 'favorite_genre'
]

def render_data_loader():
    st.markdown('<div class="netflix-brand">Step 1: Admin Dataset Ingestion</div>', unsafe_allow_html=True)
    st.markdown(
        '<div class="netflix-subhead">Upload customer churn dataset, validate schema conformity, and inspect baseline attributes.</div>',
        unsafe_allow_html=True
    )
    
    col1, col2 = st.columns([2, 1])
    
    with col1:
        st.markdown("### 📤 Upload Dataset")
        uploaded_file = st.file_uploader(
            "Choose a CSV file (e.g. Netflix Customer Churn Analysis dataset)",
            type=["csv"],
            help="Upload your customer subscription CSV file with customer attributes and churn flags."
        )
        
    with col2:
        st.markdown("### ⚡ Quick Actions")
        default_path = os.path.join("data", "netflix_customer_churn_dataset.csv")
        sample_path = os.path.join("data", "sample_dataset.csv")
        
        load_default = st.button("📁 Load Default Netflix Dataset (5,000 records)", use_container_width=True)
        
        if os.path.exists(sample_path):
            with open(sample_path, "rb") as f:
                st.download_button(
                    label="⬇️ Download Sample CSV Template",
                    data=f,
                    file_name="netflix_sample_template.csv",
                    mime="text/csv",
                    use_container_width=True
                )

    # Handling dataset loading
    if uploaded_file is not None:
        try:
            df = pd.read_csv(uploaded_file)
            st.session_state['raw_df'] = df
            st.session_state['data_source'] = f"Uploaded: {uploaded_file.name}"
            st.success(f" Successfully loaded `{uploaded_file.name}` ({len(df):,} rows)")
        except Exception as e:
            st.error(f"Error reading CSV file: {e}")
            return
    elif load_default or ('raw_df' not in st.session_state):
        if os.path.exists(default_path):
            df = pd.read_csv(default_path)
            st.session_state['raw_df'] = df
            st.session_state['data_source'] = "Default Netflix Customer Churn Dataset (5,000 records)"
            if load_default:
                st.success(" Loaded Default Netflix Internship Dataset!")
        else:
            st.warning("No dataset loaded yet. Please upload a CSV file or load default data.")
            return

    df = st.session_state.get('raw_df')
    if df is None:
        return

    st.markdown("---")
    st.markdown("### 🔍 Dataset Schema Validation & Health Check")
    
    # Check columns
    missing_cols = [c for c in EXPECTED_COLUMNS if c not in df.columns]
    extra_cols = [c for c in df.columns if c not in EXPECTED_COLUMNS]
    
    v_col1, v_col2, v_col3 = st.columns(3)
    with v_col1:
        if not missing_cols:
            st.success(" **Schema Conformity**: 100% Match with Netflix Project Schema")
        else:
            st.warning(f"⚠️ **Missing Columns**: {', '.join(missing_cols)}")
            
    with v_col2:
        if 'churned' in df.columns:
            churn_pct = df['churned'].mean() * 100
            st.info(f"🎯 **Target Column**: Found `churned` ({churn_pct:.1f}% Churn Rate)")
        else:
            st.error("❌ Target column `churned` is missing!")
            
    with v_col3:
        null_count = df.isnull().sum().sum()
        if null_count == 0:
            st.success(" **Data Completeness**: 0 missing values detected")
        else:
            st.warning(f"⚠️ **Missing Values**: {null_count:,} empty cells")

    # Metrics row
    st.markdown("### 📊 Dataset Overview Metrics")
    m1, m2, m3, m4, m5 = st.columns(5)
    
    with m1:
        st.markdown(
            f"""<div class="metric-card">
                <div class="metric-title">Total Records</div>
                <div class="metric-value">{len(df):,}</div>
                <div class="metric-delta delta-success">Rows Ingested</div>
            </div>""", unsafe_allow_html=True
        )
    with m2:
        st.markdown(
            f"""<div class="metric-card">
                <div class="metric-title">Total Features</div>
                <div class="metric-value">{df.shape[1]}</div>
                <div class="metric-delta">Attributes</div>
            </div>""", unsafe_allow_html=True
        )
    with m3:
        numeric_count = len(df.select_dtypes(include='number').columns)
        st.markdown(
            f"""<div class="metric-card">
                <div class="metric-title">Numerical Features</div>
                <div class="metric-value">{numeric_count}</div>
                <div class="metric-delta">Int / Float</div>
            </div>""", unsafe_allow_html=True
        )
    with m4:
        cat_count = len(df.select_dtypes(include=['object', 'category']).columns)
        st.markdown(
            f"""<div class="metric-card">
                <div class="metric-title">Categorical Features</div>
                <div class="metric-value">{cat_count}</div>
                <div class="metric-delta">Categories / Text</div>
            </div>""", unsafe_allow_html=True
        )
    with m5:
        mem_mb = df.memory_usage().sum() / (1024 * 1024)
        st.markdown(
            f"""<div class="metric-card">
                <div class="metric-title">Memory Footprint</div>
                <div class="metric-value">{mem_mb:.2f} MB</div>
                <div class="metric-delta delta-success">In-Memory</div>
            </div>""", unsafe_allow_html=True
        )

    # Data preview and types
    st.markdown("### 📑 Raw Dataset Inspection")
    tab_sample, tab_types, tab_stats = st.tabs(["📋 Sample Records", "🏷️ Column Types & Cardinality", "📈 Summary Statistics"])
    
    with tab_sample:
        row_limit = st.slider("Display row count:", min_value=5, max_value=100, value=10, step=5)
        st.dataframe(df.head(row_limit), use_container_width=True)
        
    with tab_types:
        dtype_df = pd.DataFrame({
            'Column Name': df.columns,
            'Data Type': [str(t) for t in df.dtypes],
            'Non-Null Count': [df[c].count() for c in df.columns],
            'Null Count': [df[c].isnull().sum() for c in df.columns],
            'Unique Values': [df[c].nunique() for c in df.columns],
            'Sample Values': [str(df[c].dropna().unique()[:3].tolist()) for c in df.columns]
        })
        st.dataframe(dtype_df, use_container_width=True)
        
    with tab_stats:
        st.dataframe(df.describe().T.round(2), use_container_width=True)
        
    st.info("💡 Next Step: Click on **'2. System Cleaning & Processing'** in the navigation menu to clean, standardize, and engineer features.")
