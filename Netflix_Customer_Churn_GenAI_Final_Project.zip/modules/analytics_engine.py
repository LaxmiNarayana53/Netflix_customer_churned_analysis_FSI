"""
Module 3: Analytics Engine Generates Customer Insights & Gen AI Q&A
Provides correlation analysis, behavioral segment diagnostics, Gen AI executive synthesis, and conversational dataset Q&A.
"""

import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
from utils.llm_helper import generate_ai_response
from utils.styles import get_chart_theme

def render_analytics_engine():
    st.markdown('<div class="netflix-brand">Step 3: Analytics Engine & Gen AI Customer Insights</div>', unsafe_allow_html=True)
    st.markdown(
        '<div class="netflix-subhead">Explore behavioral churn drivers, multi-dimensional correlations, and generate Gen AI executive diagnostics.</div>',
        unsafe_allow_html=True
    )
    
    df = st.session_state.get('processed_df')
    if df is None:
        st.warning("⚠️ No processed dataset available. Please visit **'2. System Cleaning & Processing'** first.")
        return
        
    tab_drivers, tab_crosstab, tab_genai, tab_chat = st.tabs([
        "🔬 Churn Driver Analysis", 
        "📊 Segment Cross-Tabs", 
        "⚡ Gen AI Strategic Briefing", 
        "💬 Ask Gen AI About Dataset"
    ])
    
    # TAB 1: Churn Drivers & Correlation
    with tab_drivers:
        st.markdown("### 🎯 Key Behavioral Drivers of Churn")
        
        # Calculate correlation with churned
        num_df = df.select_dtypes(include='number')
        if 'churned' in num_df.columns:
            corr_series = num_df.corr()['churned'].drop('churned').sort_values()
            
            corr_df = pd.DataFrame({
                'Feature': corr_series.index,
                'Correlation with Churn': corr_series.values,
                'Impact': ['Retention Anchor (Negative)' if v < 0 else 'Churn Driver (Positive)' for v in corr_series.values]
            })
            
            fig_corr = px.bar(
                corr_df,
                x='Correlation with Churn',
                y='Feature',
                orientation='h',
                color='Impact',
                color_discrete_map={
                    'Retention Anchor (Negative)': '#46D369',
                    'Churn Driver (Positive)': '#E50914'
                },
                title="Feature Correlation with Churn Risk (Pearson r)",
                template='plotly_dark'
            )
            fig_corr.update_layout(height=400, margin=dict(l=20, r=20, t=40, b=20))
            st.plotly_chart(fig_corr, use_container_width=True)
            
            st.markdown("""
            **Interpretation:**
            - **Positive Correlation (Red)**: As `last_login_days` (inactivity) and `fee_per_profile` increase, customer churn risk rises sharply.
            - **Negative Correlation (Green)**: Higher `watch_hours` and frequent logins act as strong retention anchors that safeguard subscribers.
            """)
            
    # TAB 2: Multi-dimensional Cross-tabulations
    with tab_crosstab:
        st.markdown("### 🧩 Segment Cross-Tabulation Explorer")
        
        col_x, col_y = st.columns(2)
        cat_columns = [c for c in ['subscription_type', 'device', 'payment_method', 'region', 'favorite_genre', 'age_group', 'watch_category'] if c in df.columns]
        
        with col_x:
            dim_1 = st.selectbox("Primary Dimension (Rows):", cat_columns, index=0)
        with col_y:
            dim_2 = st.selectbox("Secondary Dimension (Columns):", cat_columns, index=min(2, len(cat_columns)-1))
            
        if dim_1 != dim_2:
            pivot_churn = df.pivot_table(index=dim_1, columns=dim_2, values='churned', aggfunc='mean') * 100
            
            fig_heat = px.imshow(
                pivot_churn,
                labels=dict(x=dim_2.replace('_', ' ').title(), y=dim_1.replace('_', ' ').title(), color="Churn Rate (%)"),
                color_continuous_scale="Reds",
                text_auto=".1f",
                title=f"Churn Rate Heatmap (%): {dim_1.title()} vs {dim_2.title()}",
                template='plotly_dark'
            )
            fig_heat.update_layout(height=450, margin=dict(l=20, r=20, t=40, b=20))
            st.plotly_chart(fig_heat, use_container_width=True)
        else:
            st.info("Select two distinct dimensions to view the bivariate churn matrix.")
            
    # TAB 3: Gen AI Strategic Executive Briefing
    with tab_genai:
        st.markdown("### ⚡ Automated Gen AI Strategic Diagnostic")
        st.write("Generate an executive-level diagnostic report identifying critical retention threats and revenue risks across the platform.")
        
        api_key = st.session_state.get('openai_api_key', '')
        
        if st.button("🧠 Synthesize Executive Churn Diagnostic", use_container_width=True):
            with st.spinner("Gen AI Analytics Engine is analyzing patterns, identifying anomalies, and synthesizing strategic recommendations..."):
                prompt = (
                    "Provide an executive-level strategic diagnostic briefing on Netflix customer churn. "
                    "Analyze subscriber base health, inactivity inflection points, payment channel leakage, "
                    "and deliver three targeted, high-impact business retention recommendations."
                )
                ai_briefing = generate_ai_response(prompt, context_df=df, api_key=api_key)
                st.session_state['executive_briefing'] = ai_briefing
                
        if 'executive_briefing' in st.session_state:
            st.markdown(f"""
            <div class="ai-box">
                <div class="ai-box-title">🧠 Executive Intelligence Synthesis</div>
                <div class="ai-box-body">{st.session_state['executive_briefing']}</div>
            </div>
            """, unsafe_allow_html=True)
            
    # TAB 4: Interactive Natural Language Q&A Chat
    with tab_chat:
        st.markdown("### 💬 Ask Gen AI About The Dataset")
        st.write("Ask questions in natural English regarding customer behavior, demographic patterns, payment channels, or churn risks.")
        
        # Sample prompt buttons
        st.markdown("**Quick Prompts:**")
        qp_cols = st.columns(4)
        sample_q = ""
        with qp_cols[0]:
            if st.button("💳 Payment Churn Risk", use_container_width=True):
                sample_q = "Which payment method has the highest churn rate and why?"
        with qp_cols[1]:
            if st.button("⏱️ Inactivity Impact", use_container_width=True):
                sample_q = "What is the churn rate for subscribers inactive for over 30 days?"
        with qp_cols[2]:
            if st.button("🎬 Genre & Streaming", use_container_width=True):
                sample_q = "How do watch hours and favorite genre impact customer retention?"
        with qp_cols[3]:
            if st.button("📧 Retention Campaign", use_container_width=True):
                sample_q = "Generate a personalized retention email campaign for high-risk subscribers."

        # Input box
        user_query = st.text_input("Enter your question:", value=sample_q, placeholder="e.g. Which customer group is at highest risk of cancellation?")
        
        if st.button("Send Query", use_container_width=True) or (sample_q and user_query):
            if user_query.strip():
                with st.spinner("Analyzing dataset metrics and formulating AI response..."):
                    api_key = st.session_state.get('openai_api_key', '')
                    resp = generate_ai_response(user_query, context_df=df, api_key=api_key)
                    
                    st.markdown(f"""
                    <div class="ai-box">
                        <div class="ai-box-title">🤖 Gen AI Answer</div>
                        <div class="ai-box-body">{resp}</div>
                    </div>
                    """, unsafe_allow_html=True)

    st.info("💡 Next Step: Click on **'4. ML Churn Predictor'** to train predictive machine learning models and run single-customer simulations.")
