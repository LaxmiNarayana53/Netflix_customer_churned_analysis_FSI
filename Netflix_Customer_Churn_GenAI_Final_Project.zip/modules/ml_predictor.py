"""
Module 4: Machine Learning Churn Predictor
Trains Random Forest, Gradient Boosting, and Logistic Regression models.
Evaluates metrics (ROC-AUC, F1, Accuracy), plots Confusion Matrix & ROC curves,
scores customer risk tiers, and provides an interactive Single-Customer Simulator.
"""

import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier, HistGradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score, confusion_matrix, roc_curve
from utils.llm_helper import generate_ai_response

def prepare_ml_data(df: pd.DataFrame):
    """
    Encodes categoricals and prepares feature matrix X and target y.
    """
    df_ml = df.copy()
    
    # Drop non-predictive identifiers
    if 'customer_id' in df_ml.columns:
        df_ml = df_ml.drop(columns=['customer_id'])
        
    # Drop target
    y = df_ml['churned'].astype(int)
    X = df_ml.drop(columns=['churned'])
    
    # Keep numeric features & one-hot encode categoricals
    cat_cols = X.select_dtypes(include=['object', 'category']).columns.tolist()
    X = pd.get_dummies(X, columns=cat_cols, drop_first=True)
    
    # Ensure float conversion
    X = X.astype(float)
    return X, y

def train_and_evaluate_models(X: pd.DataFrame, y: pd.Series):
    """
    Trains 3 ML algorithms and computes cross-comparative performance metrics.
    """
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.20, random_state=42, stratify=y
    )
    
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)
    
    models = {
        'Random Forest': RandomForestClassifier(n_estimators=100, max_depth=10, random_state=42, n_jobs=1),
        'Gradient Boosting': HistGradientBoostingClassifier(max_iter=100, max_depth=6, random_state=42),
        'Logistic Regression': LogisticRegression(max_iter=1000, random_state=42)
    }
    
    results = {}
    trained_objects = {}
    
    for name, clf in models.items():
        if name == 'Logistic Regression':
            clf.fit(X_train_scaled, y_train)
            y_pred = clf.predict(X_test_scaled)
            y_prob = clf.predict_proba(X_test_scaled)[:, 1]
        else:
            clf.fit(X_train, y_train)
            y_pred = clf.predict(X_test)
            y_prob = clf.predict_proba(X_test)[:, 1]
            
        acc = accuracy_score(y_test, y_pred)
        prec = precision_score(y_test, y_pred, zero_division=0)
        rec = recall_score(y_test, y_pred, zero_division=0)
        f1 = f1_score(y_test, y_pred, zero_division=0)
        auc = roc_auc_score(y_test, y_prob)
        cm = confusion_matrix(y_test, y_pred)
        fpr, tpr, _ = roc_curve(y_test, y_prob)
        
        results[name] = {
            'Accuracy': acc,
            'Precision': prec,
            'Recall': rec,
            'F1-Score': f1,
            'ROC-AUC': auc,
            'Confusion Matrix': cm,
            'FPR': fpr,
            'TPR': tpr,
            'y_test': y_test,
            'y_prob': y_prob
        }
        trained_objects[name] = clf
        
    return results, trained_objects, scaler, X.columns.tolist()

def render_ml_predictor():
    st.markdown('<div class="netflix-brand">Step 4: Machine Learning Churn Risk Predictor</div>', unsafe_allow_html=True)
    st.markdown(
        '<div class="netflix-subhead">Train, compare, and deploy supervised ML classifiers to predict customer churn probability and risk tiers.</div>',
        unsafe_allow_html=True
    )
    
    df = st.session_state.get('processed_df')
    if df is None:
        st.warning("⚠️ No processed dataset available. Please complete step 2 first.")
        return
        
    col_t1, col_t2 = st.columns([1, 2])
    with col_t1:
        retrain = st.button("⚡ Train & Evaluate ML Models", use_container_width=True)
        
    # Auto-train if not already present
    if retrain or ('ml_results' not in st.session_state):
        with st.spinner("Training Random Forest, Gradient Boosting, and Logistic Regression models..."):
            X, y = prepare_ml_data(df)
            results, trained_objs, scaler, feature_cols = train_and_evaluate_models(X, y)
            st.session_state['ml_results'] = results
            st.session_state['ml_models'] = trained_objs
            st.session_state['ml_scaler'] = scaler
            st.session_state['ml_feature_cols'] = feature_cols
            st.session_state['ml_X'] = X
            st.session_state['ml_y'] = y
            if retrain:
                st.success(" Models trained and evaluated successfully!")

    results = st.session_state['ml_results']
    trained_objs = st.session_state['ml_models']
    feature_cols = st.session_state['ml_feature_cols']
    X = st.session_state['ml_X']
    
    # 1. Comparison Leaderboard
    st.markdown("### 🏆 Model Performance Leaderboard")
    leaderboard = []
    for model_name, m in results.items():
        leaderboard.append({
            'Model Architecture': model_name,
            'ROC-AUC Score': f"{m['ROC-AUC']:.4f}",
            'Accuracy': f"{m['Accuracy'] * 100:.2f}%",
            'F1-Score': f"{m['F1-Score']:.4f}",
            'Precision': f"{m['Precision'] * 100:.2f}%",
            'Recall (Sensitivity)': f"{m['Recall'] * 100:.2f}%"
        })
    df_leaderboard = pd.DataFrame(leaderboard).sort_values(by='ROC-AUC Score', ascending=False)
    st.dataframe(df_leaderboard, use_container_width=True)
    
    best_model_name = df_leaderboard.iloc[0]['Model Architecture']
    best_auc = df_leaderboard.iloc[0]['ROC-AUC Score']
    st.success(f"🌟 **Champion Model**: `{best_model_name}` achieved top discriminative performance with **ROC-AUC = {best_auc}**.")

    # 2. Tabs for Model Diagnostics & Predictions
    tab_eval, tab_feat, tab_batch, tab_sim = st.tabs([
        "📈 Visual Diagnostics (ROC & Confusion Matrix)",
        "🔑 Feature Importance",
        "👥 Full Dataset Risk Scoring",
        "🎯 Single-Customer Simulator"
    ])
    
    with tab_eval:
        sel_model = st.selectbox("Select Model for Visual Inspection:", list(results.keys()), index=0)
        m_data = results[sel_model]
        
        c_diag1, c_diag2 = st.columns(2)
        with c_diag1:
            # Confusion matrix
            cm = m_data['Confusion Matrix']
            fig_cm = px.imshow(
                cm,
                text_auto=True,
                labels=dict(x="Predicted Churn Status", y="Actual Churn Status"),
                x=['Retained (0)', 'Churned (1)'],
                y=['Retained (0)', 'Churned (1)'],
                color_continuous_scale="Reds",
                title=f"Confusion Matrix: {sel_model}",
                template='plotly_dark'
            )
            fig_cm.update_layout(height=380, margin=dict(l=20, r=20, t=40, b=20))
            st.plotly_chart(fig_cm, use_container_width=True)
            
        with c_diag2:
            # ROC Curves
            fig_roc = go.Figure()
            for name, r in results.items():
                fig_roc.add_trace(go.Scatter(
                    x=r['FPR'], y=r['TPR'],
                    mode='lines',
                    name=f"{name} (AUC={r['ROC-AUC']:.3f})"
                ))
            fig_roc.add_trace(go.Scatter(
                x=[0, 1], y=[0, 1],
                mode='lines',
                line=dict(dash='dash', color='#666666'),
                name='Random Chance (AUC=0.50)'
            ))
            fig_roc.update_layout(
                title="ROC Curves Comparison",
                xaxis_title="False Positive Rate",
                yaxis_title="True Positive Rate",
                template='plotly_dark',
                height=380,
                margin=dict(l=20, r=20, t=40, b=20)
            )
            st.plotly_chart(fig_roc, use_container_width=True)

    with tab_feat:
        st.markdown("### 🔍 Global Churn Feature Importance")
        # Extract feature importance from Random Forest
        rf_clf = trained_objs.get('Random Forest')
        if hasattr(rf_clf, 'feature_importances_'):
            importances = rf_clf.feature_importances_
            feat_imp_df = pd.DataFrame({
                'Feature': feature_cols,
                'Importance': importances
            }).sort_values(by='Importance', ascending=False).head(12)
            
            fig_imp = px.bar(
                feat_imp_df,
                x='Importance',
                y='Feature',
                orientation='h',
                color='Importance',
                color_continuous_scale='Reds',
                title="Top 12 Churn Predictor Features (Random Forest MDI)",
                template='plotly_dark'
            )
            fig_imp.update_layout(height=420, margin=dict(l=20, r=20, t=40, b=20), yaxis=dict(autorange="reversed"))
            st.plotly_chart(fig_imp, use_container_width=True)

    with tab_batch:
        st.markdown("### 🎯 Dataset-Wide Churn Risk Tier Segmentation")
        
        # Score entire dataset using best model
        best_clf = trained_objs[best_model_name]
        if best_model_name == 'Logistic Regression':
            scaler = st.session_state['ml_scaler']
            probs = best_clf.predict_proba(scaler.transform(X))[:, 1]
        else:
            probs = best_clf.predict_proba(X)[:, 1]
            
        df_scored = df.copy()
        df_scored['churn_probability'] = np.round(probs, 4)
        
        conditions = [
            (df_scored['churn_probability'] >= 0.65),
            (df_scored['churn_probability'] >= 0.35) & (df_scored['churn_probability'] < 0.65),
            (df_scored['churn_probability'] < 0.35)
        ]
        tier_labels = ['🔴 High Risk', '🟡 Medium Risk', '🟢 Low Risk']
        df_scored['risk_tier'] = np.select(conditions, tier_labels, default='🟢 Low Risk')
        st.session_state['df_scored'] = df_scored
        
        r1, r2, r3, r4 = st.columns(4)
        high_cnt = (df_scored['risk_tier'] == '🔴 High Risk').sum()
        med_cnt = (df_scored['risk_tier'] == '🟡 Medium Risk').sum()
        low_cnt = (df_scored['risk_tier'] == '🟢 Low Risk').sum()
        
        with r1:
            st.markdown(
                f"""<div class="metric-card">
                    <div class="metric-title">🔴 High Risk Accounts</div>
                    <div class="metric-value">{high_cnt:,}</div>
                    <div class="metric-delta delta-danger">{high_cnt/len(df)*100:.1f}% of Platform</div>
                </div>""", unsafe_allow_html=True
            )
        with r2:
            st.markdown(
                f"""<div class="metric-card">
                    <div class="metric-title">🟡 Medium Risk Accounts</div>
                    <div class="metric-value">{med_cnt:,}</div>
                    <div class="metric-delta delta-warning">{med_cnt/len(df)*100:.1f}% of Platform</div>
                </div>""", unsafe_allow_html=True
            )
        with r3:
            st.markdown(
                f"""<div class="metric-card">
                    <div class="metric-title">🟢 Low Risk Accounts</div>
                    <div class="metric-value">{low_cnt:,}</div>
                    <div class="metric-delta delta-success">{low_cnt/len(df)*100:.1f}% of Platform</div>
                </div>""", unsafe_allow_html=True
            )
        with r4:
            high_risk_revenue = df_scored[df_scored['risk_tier'] == '🔴 High Risk']['monthly_fee'].sum()
            st.markdown(
                f"""<div class="metric-card">
                    <div class="metric-title">Revenue at Immediate Risk</div>
                    <div class="metric-value">${high_risk_revenue:,.0f}</div>
                    <div class="metric-delta delta-danger">Monthly Run-rate</div>
                </div>""", unsafe_allow_html=True
            )
            
        st.markdown("#### 🚨 High-Risk Priority Watchlist")
        cols_watch = ['customer_id', 'risk_tier', 'churn_probability', 'subscription_type', 'last_login_days', 'watch_hours', 'monthly_fee', 'payment_method']
        watch_df = df_scored[df_scored['risk_tier'] == '🔴 High Risk'][cols_watch].sort_values(by='churn_probability', ascending=False)
        st.dataframe(watch_df.head(15), use_container_width=True)
        
        csv_watch = watch_df.to_csv(index=False).encode('utf-8')
        st.download_button(
            "⬇️ Export High-Risk Watchlist (CSV)",
            data=csv_watch,
            file_name="netflix_high_risk_subscribers.csv",
            mime="text/csv"
        )

    with tab_sim:
        st.markdown("### 🎛️ Interactive Single-Customer Churn Simulator")
        st.write("Adjust customer attributes below to simulate churn probability and receive instant Gen AI retention advice.")
        
        sim_c1, sim_c2, sim_c3 = st.columns(3)
        with sim_c1:
            sim_age = st.slider("Customer Age:", 18, 70, 35)
            sim_gender = st.selectbox("Gender:", ['Female', 'Male', 'Other'], index=0)
            sim_sub = st.selectbox("Subscription Type:", ['Basic', 'Standard', 'Premium'], index=1)
            fee_defaults = {'Basic': 8.99, 'Standard': 13.99, 'Premium': 17.99}
            sim_fee = st.number_input("Monthly Fee ($):", value=fee_defaults[sim_sub], step=1.0)
            
        with sim_c2:
            sim_profiles = st.slider("Profiles on Account:", 1, 5, 2)
            sim_watch = st.slider("Total Monthly Watch Hours:", 0.0, 100.0, 12.0, step=0.5)
            sim_avg_watch = st.slider("Avg Daily Watch Time (hrs/day):", 0.0, 10.0, round(sim_watch/30, 2), step=0.1)
            sim_login = st.slider("Days Since Last Login:", 0, 60, 15)
            
        with sim_c3:
            sim_device = st.selectbox("Primary Device:", ['TV', 'Mobile', 'Laptop', 'Desktop', 'Tablet'], index=0)
            sim_pay = st.selectbox("Payment Method:", ['Credit Card', 'Debit Card', 'PayPal', 'Gift Card', 'Crypto'], index=0)
            sim_region = st.selectbox("Region:", ['North America', 'Europe', 'Asia', 'South America', 'Africa', 'Oceania'], index=0)
            sim_genre = st.selectbox("Favorite Genre:", ['Action', 'Sci-Fi', 'Drama', 'Horror', 'Romance', 'Comedy', 'Documentary'], index=0)

        # Build feature vector
        sim_record = pd.DataFrame([{
            'age': sim_age,
            'gender': sim_gender,
            'subscription_type': sim_sub,
            'watch_hours': sim_watch,
            'last_login_days': sim_login,
            'region': sim_region,
            'device': sim_device,
            'monthly_fee': sim_fee,
            'payment_method': sim_pay,
            'number_of_profiles': sim_profiles,
            'avg_watch_time_per_day': sim_avg_watch,
            'favorite_genre': sim_genre,
            'fee_per_profile': sim_fee / sim_profiles,
            'inactivity_ratio': sim_login / 60.0
        }])
        
        # Categorize
        sim_record["age_group"] = pd.cut(sim_record["age"], bins=[0, 18, 30, 45, 60, 100], labels=["Teen", "Young Adult", "Adult", "Middle Age", "Senior"])
        sim_record["watch_category"] = pd.cut(sim_record["watch_hours"], bins=[-np.inf, 20, 40, 60, np.inf], labels=["Low", "Medium", "High", "Very High"])
        sim_record["engagement_level"] = pd.cut(sim_record["avg_watch_time_per_day"], bins=[-np.inf, 1, 2, 4, np.inf], labels=["Low", "Medium", "High", "Very High"])
        sim_record["subscription_group"] = sim_record["subscription_type"]

        # Align with X columns
        sim_encoded = pd.get_dummies(sim_record)
        sim_vector = pd.DataFrame(0.0, index=[0], columns=feature_cols)
        for c in sim_encoded.columns:
            if c in sim_vector.columns:
                sim_vector[c] = float(sim_encoded[c].iloc[0])

        best_clf = trained_objs[best_model_name]
        if best_model_name == 'Logistic Regression':
            scaler = st.session_state['ml_scaler']
            prob_sim = best_clf.predict_proba(scaler.transform(sim_vector))[0, 1]
        else:
            prob_sim = best_clf.predict_proba(sim_vector)[0, 1]

        # Display Gauge & Result
        st.markdown("#### 🎯 Prediction Outcome")
        sim_g1, sim_g2 = st.columns([1, 1])
        
        with sim_g1:
            fig_gauge = go.Figure(go.Indicator(
                mode="gauge+number",
                value=prob_sim * 100,
                domain={'x': [0, 1], 'y': [0, 1]},
                title={'text': "Simulated Churn Probability (%)", 'font': {'color': '#FFFFFF'}},
                gauge={
                    'axis': {'range': [0, 100], 'tickcolor': '#AAAAAA'},
                    'bar': {'color': "#E50914" if prob_sim >= 0.65 else ("#FFA00A" if prob_sim >= 0.35 else "#46D369")},
                    'steps': [
                        {'range': [0, 35], 'color': "rgba(70, 211, 105, 0.2)"},
                        {'range': [35, 65], 'color': "rgba(255, 160, 10, 0.2)"},
                        {'range': [65, 100], 'color': "rgba(229, 9, 20, 0.2)"}
                    ],
                    'threshold': {
                        'line': {'color': "#E50914", 'width': 4},
                        'thickness': 0.75,
                        'value': 65
                    }
                }
            ))
            fig_gauge.update_layout(paper_bgcolor="rgba(0,0,0,0)", height=280, margin=dict(l=20, r=20, t=30, b=10))
            st.plotly_chart(fig_gauge, use_container_width=True)

        with sim_g2:
            if prob_sim >= 0.65:
                st.markdown('<span class="badge-high">🚨 HIGH RISK CUSTOMER</span>', unsafe_allow_html=True)
                sim_status = "High risk of immediate cancellation within the next 30 days."
            elif prob_sim >= 0.35:
                st.markdown('<span class="badge-med">⚠️ MEDIUM RISK (ATTENTION NEEDED)</span>', unsafe_allow_html=True)
                sim_status = "Moderate risk. Early proactive engagement recommended."
            else:
                st.markdown('<span class="badge-low"> STABLE & HEALTHY SUBSCRIBER</span>', unsafe_allow_html=True)
                sim_status = "Low churn probability. Strong retention indicators."
                
            st.markdown(f"**Assessment**: {sim_status}")
            st.markdown(f"""
            - **Estimated Churn Probability**: **{prob_sim*100:.1f}%**
            - **Monthly Revenue Impact**: **${sim_fee:.2f} / mo**
            - **Key Factor**: {'Critical Inactivity Gap' if sim_login > 25 else ('Low Watch Time' if sim_watch < 6 else 'Friction in Payment Channel' if sim_pay in ['Crypto', 'Gift Card'] else 'Balanced Profile')}
            """)
            
            # Instant Gen AI Action Advice
            if st.button("🤖 Generate Tailored Retention Action", use_container_width=True):
                p_text = f"Advise immediate retention action for subscriber: Age {sim_age}, Plan {sim_sub}, Inactive {sim_login} days, Watch hours {sim_watch}, Payment {sim_pay}, Churn Prob {prob_sim:.1%}."
                action_text = generate_ai_response(p_text, context_df=df)
                st.info(action_text)

    st.info("💡 Next Step: Click on **'5. Executive Dashboard'** to view the interactive Netflix KPI command center.")
