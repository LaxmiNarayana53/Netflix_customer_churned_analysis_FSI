"""
Netflix Dark Modern Styling & Flexible Glassmorphic Theme for Streamlit Application
Authored by: K. Laxmi Narayana (23341A4253)
"""

def get_custom_css():
    return """
    <style>
    /* Google Fonts Import */
    @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap');

    /* Main App Background & Typography */
    .stApp {
        background: radial-gradient(circle at top left, #1a0808 0%, #111111 40%, #0d0d0d 100%);
        color: #F3F4F6;
        font-family: 'Plus Jakarta Sans', -apple-system, BlinkMacSystemFont, sans-serif;
    }
    
    /* Netflix Brand Header */
    .netflix-brand-badge {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        background: rgba(229, 9, 20, 0.12);
        border: 1px solid rgba(229, 9, 20, 0.35);
        border-radius: 30px;
        padding: 5px 14px;
        font-size: 0.78rem;
        font-weight: 700;
        letter-spacing: 1.5px;
        color: #E50914;
        text-transform: uppercase;
        margin-bottom: 8px;
    }

    .netflix-brand {
        color: #E50914;
        font-size: 2.3rem;
        font-weight: 800;
        letter-spacing: -0.5px;
        margin: 0;
        padding: 0;
        line-height: 1.2;
        text-shadow: 0 0 30px rgba(229, 9, 20, 0.35);
    }
    
    .netflix-subhead {
        color: #9CA3AF;
        font-size: 1.02rem;
        font-weight: 400;
        margin-top: 6px;
        margin-bottom: 1.5rem;
        line-height: 1.5;
    }

    /* Author Hero Card */
    .author-card {
        background: linear-gradient(135deg, rgba(229, 9, 20, 0.08) 0%, rgba(20, 20, 20, 0.6) 100%);
        border: 1px solid rgba(229, 9, 20, 0.25);
        border-radius: 12px;
        padding: 14px 18px;
        margin-bottom: 20px;
        backdrop-filter: blur(10px);
    }
    .author-name {
        color: #FFFFFF;
        font-size: 1.05rem;
        font-weight: 700;
    }
    .author-meta {
        color: #9CA3AF;
        font-size: 0.82rem;
        margin-top: 3px;
    }

    /* Glassmorphic Metric Cards */
    .metric-card {
        background: linear-gradient(145deg, rgba(32, 32, 36, 0.75) 0%, rgba(20, 20, 22, 0.85) 100%);
        border: 1px solid rgba(255, 255, 255, 0.08);
        border-radius: 14px;
        padding: 18px 20px;
        margin-bottom: 15px;
        box-shadow: 0 8px 24px rgba(0, 0, 0, 0.35);
        backdrop-filter: blur(12px);
        transition: all 0.25s cubic-bezier(0.4, 0, 0.2, 1);
        position: relative;
        overflow: hidden;
    }
    .metric-card::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        height: 2px;
        background: linear-gradient(90deg, transparent, rgba(229, 9, 20, 0.4), transparent);
    }
    .metric-card:hover {
        transform: translateY(-3px);
        border-color: rgba(229, 9, 20, 0.45);
        box-shadow: 0 12px 28px rgba(229, 9, 20, 0.15);
    }
    .metric-title {
        color: #9CA3AF;
        font-size: 0.8rem;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.8px;
        margin-bottom: 6px;
    }
    .metric-value {
        color: #FFFFFF;
        font-size: 1.9rem;
        font-weight: 800;
        letter-spacing: -0.5px;
        line-height: 1.1;
    }
    .metric-delta {
        font-size: 0.82rem;
        font-weight: 600;
        margin-top: 6px;
        display: flex;
        align-items: center;
        gap: 4px;
    }
    .delta-danger { color: #FF4D4D; }
    .delta-success { color: #46D369; }
    .delta-warning { color: #FFA00A; }

    /* Interactive Flexible Top Nav Bar */
    .nav-bar-container {
        display: flex;
        flex-wrap: wrap;
        gap: 8px;
        background: rgba(18, 18, 20, 0.65);
        padding: 8px 12px;
        border-radius: 16px;
        border: 1px solid rgba(255, 255, 255, 0.08);
        backdrop-filter: blur(15px);
        margin-bottom: 25px;
    }
    .step-pill {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        padding: 8px 16px;
        border-radius: 12px;
        font-size: 0.85rem;
        font-weight: 600;
        background: rgba(255, 255, 255, 0.04);
        color: #9CA3AF;
        border: 1px solid rgba(255, 255, 255, 0.06);
        text-decoration: none;
        transition: all 0.2s ease;
    }
    .step-pill:hover {
        background: rgba(255, 255, 255, 0.08);
        color: #FFFFFF;
    }
    .step-pill-active {
        background: linear-gradient(135deg, #E50914 0%, #B80710 100%) !important;
        color: #FFFFFF !important;
        border-color: #E50914 !important;
        box-shadow: 0 4px 18px rgba(229, 9, 20, 0.45);
    }

    /* Badges */
    .badge-high {
        background-color: rgba(229, 9, 20, 0.2);
        color: #FF5A5A;
        border: 1px solid rgba(229, 9, 20, 0.4);
        padding: 5px 12px;
        border-radius: 8px;
        font-size: 0.82rem;
        font-weight: 700;
        display: inline-block;
    }
    .badge-med {
        background-color: rgba(255, 160, 10, 0.18);
        color: #FFB338;
        border: 1px solid rgba(255, 160, 10, 0.4);
        padding: 5px 12px;
        border-radius: 8px;
        font-size: 0.82rem;
        font-weight: 700;
        display: inline-block;
    }
    .badge-low {
        background-color: rgba(70, 211, 105, 0.18);
        color: #55E478;
        border: 1px solid rgba(70, 211, 105, 0.4);
        padding: 5px 12px;
        border-radius: 8px;
        font-size: 0.82rem;
        font-weight: 700;
        display: inline-block;
    }

    /* Gen AI Card Container */
    .ai-box {
        background: linear-gradient(145deg, rgba(22, 18, 28, 0.9) 0%, rgba(16, 16, 22, 0.95) 100%);
        border: 1px solid rgba(139, 92, 246, 0.3);
        border-left: 4px solid #E50914;
        border-radius: 12px;
        padding: 20px 24px;
        margin: 18px 0;
        box-shadow: 0 8px 30px rgba(0, 0, 0, 0.5);
    }
    .ai-box-title {
        color: #FFFFFF;
        font-weight: 700;
        font-size: 1.1rem;
        margin-bottom: 12px;
        display: flex;
        align-items: center;
        gap: 10px;
    }
    .ai-box-body {
        color: #E2E8F0;
        font-size: 0.95rem;
        line-height: 1.65;
    }

    /* Primary Buttons Styling */
    .stButton > button {
        background: linear-gradient(135deg, #E50914 0%, #C40812 100%) !important;
        color: #FFFFFF !important;
        font-weight: 700 !important;
        font-size: 0.9rem !important;
        letter-spacing: 0.3px !important;
        border-radius: 10px !important;
        border: 1px solid rgba(255, 255, 255, 0.1) !important;
        padding: 0.55rem 1.3rem !important;
        box-shadow: 0 4px 14px rgba(229, 9, 20, 0.3) !important;
        transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1) !important;
    }
    .stButton > button:hover {
        background: linear-gradient(135deg, #FF1A27 0%, #E50914 100%) !important;
        box-shadow: 0 6px 22px rgba(229, 9, 20, 0.5) !important;
        transform: translateY(-2px) !important;
    }

    /* Secondary / Navigation Buttons */
    .stButton > button[kind="secondary"] {
        background: rgba(255, 255, 255, 0.05) !important;
        border: 1px solid rgba(255, 255, 255, 0.12) !important;
        color: #E2E8F0 !important;
    }
    .stButton > button[kind="secondary"]:hover {
        background: rgba(255, 255, 255, 0.1) !important;
        border-color: rgba(229, 9, 20, 0.4) !important;
    }

    /* Dataframe Container */
    .stDataFrame {
        border-radius: 12px;
        border: 1px solid rgba(255, 255, 255, 0.08);
        overflow: hidden;
        background: rgba(18, 18, 20, 0.7);
    }
    
    /* Styled Tabs */
    .stTabs [data-baseweb="tab-list"] {
        gap: 8px;
        background-color: transparent;
        border-bottom: 1px solid rgba(255, 255, 255, 0.08);
        padding-bottom: 6px;
    }
    .stTabs [data-baseweb="tab"] {
        border-radius: 8px 8px 0 0;
        padding: 8px 16px;
        color: #9CA3AF;
        font-weight: 600;
        border: none;
        background-color: transparent;
    }
    .stTabs [aria-selected="true"] {
        color: #E50914 !important;
        border-bottom: 2px solid #E50914 !important;
        background-color: rgba(229, 9, 20, 0.08) !important;
    }

    /* Clean Footer */
    .netflix-footer {
        text-align: center;
        padding: 35px 15px 20px;
        color: #6B7280;
        font-size: 0.85rem;
        border-top: 1px solid rgba(255, 255, 255, 0.06);
        margin-top: 50px;
    }
    .netflix-footer a {
        color: #E50914;
        text-decoration: none;
        font-weight: 600;
    }
    </style>
    """

def get_chart_theme():
    return {
        'layout': {
            'paper_bgcolor': 'rgba(18,18,20,0)',
            'plot_bgcolor': 'rgba(18,18,20,0)',
            'font': {'color': '#E5E7EB', 'family': 'Plus Jakarta Sans, sans-serif'},
            'xaxis': {
                'gridcolor': 'rgba(255, 255, 255, 0.06)',
                'zerolinecolor': 'rgba(255, 255, 255, 0.1)'
            },
            'yaxis': {
                'gridcolor': 'rgba(255, 255, 255, 0.06)',
                'zerolinecolor': 'rgba(255, 255, 255, 0.1)'
            },
            'colorway': ['#E50914', '#FFA00A', '#46D369', '#3B82F6', '#8B5CF6', '#EC4899', '#14B8A6']
        }
    }
