"""
Netflix Customer Churn Analysis & Gen AI Retention Platform
Full Semester Internship Final Project
Sole Author & Developer: K. Laxmi Narayana (Roll No: 23341A4253)
Main Streamlit Application Entrypoint
"""

import streamlit as st
import os
import pandas as pd
from utils.styles import get_custom_css
from modules.data_loader import render_data_loader
from modules.data_processor import render_data_processor, clean_and_process_data
from modules.analytics_engine import render_analytics_engine
from modules.ml_predictor import render_ml_predictor, prepare_ml_data, train_and_evaluate_models
from modules.dashboard_view import render_dashboard
from modules.retention_hub import render_retention_hub

# 1. Page Configuration
st.set_page_config(
    page_title="Netflix Churn AI | K. Laxmi Narayana",
    page_icon="🍿",
    layout="wide",
    initial_sidebar_state="expanded"
)

# 2. Inject Custom Styling
st.markdown(get_custom_css(), unsafe_allow_html=True)

# 3. Define the 6 Workflow Steps
STEPS = [
    "1. Admin Dataset Ingestion",
    "2. System Cleaning & Processing",
    "3. Analytics & GenAI Insights",
    "4. ML Churn Predictor",
    "5. Executive Dashboard",
    "6. Retention & Action Hub"
]

# Initialize current step in session state
if 'current_step_idx' not in st.session_state:
    st.session_state['current_step_idx'] = 0

# Helper to change steps
def go_to_step(idx):
    st.session_state['current_step_idx'] = idx

# 4. Sidebar: Navigation & Author Information
with st.sidebar:
    st.markdown('<div class="netflix-brand-badge">🍿 NETFLIX AI INTELLIGENCE</div>', unsafe_allow_html=True)
    st.markdown('<div class="netflix-brand" style="font-size: 1.8rem;">CHURN GEN AI</div>', unsafe_allow_html=True)
    st.caption("Enterprise Retention & Machine Learning Platform")
    
    st.markdown("---")
    
    # Author Card
    st.markdown("""
    <div class="author-card">
        <div class="author-name">👨‍💻 K. Laxmi Narayana</div>
        <div class="author-meta"><b>Roll No:</b> 23341A4253</div>
        <div class="author-meta"><b>Branch:</b> Artificial Intelligence & Machine Learning</div>
        <div class="author-meta"><b>Project:</b> Full Semester Internship Final Project</div>
    </div>
    """, unsafe_allow_html=True)
    
    st.markdown("### 🧭 Workflow Navigation")
    
    # Radio navigation synced with session state index
    selected_step = st.radio(
        "Jump to Stage:",
        STEPS,
        index=st.session_state['current_step_idx'],
        key="sidebar_nav"
    )
    # Sync if user clicks radio
    st.session_state['current_step_idx'] = STEPS.index(selected_step)
    
    st.markdown("---")
    st.markdown("### ⚡ 1-Click Fast Track")
    
    # 1-Click Full Pipeline Executor
    if st.button("🚀 Run Full Pipeline Instantly", use_container_width=True, help="Automatically loads dataset, cleans data, engineers features, and trains all 3 ML models in one click!"):
        with st.spinner("Executing end-to-end pipeline: Loading data, engineering features, and training ML models..."):
            default_path = os.path.join("data", "netflix_customer_churn_dataset.csv")
            if os.path.exists(default_path):
                raw_df = pd.read_csv(default_path)
                st.session_state['raw_df'] = raw_df
                st.session_state['data_source'] = "Default Netflix Customer Churn Dataset (5,000 records)"
                
                # Cleaning & processing
                proc_df, logs = clean_and_process_data(raw_df)
                st.session_state['processed_df'] = proc_df
                st.session_state['clean_logs'] = logs
                
                # ML Training
                X, y = prepare_ml_data(proc_df)
                results, trained_objs, scaler, feature_cols = train_and_evaluate_models(X, y)
                st.session_state['ml_results'] = results
                st.session_state['ml_models'] = trained_objs
                st.session_state['ml_scaler'] = scaler
                st.session_state['ml_feature_cols'] = feature_cols
                st.session_state['ml_X'] = X
                st.session_state['ml_y'] = y
                
                st.success(" Full Pipeline Ready! Jump into any step.")
            else:
                st.error("Dataset file not found at data/netflix_customer_churn_dataset.csv")
                
    st.markdown("---")
    st.markdown("### 🤖 Gen AI Settings")
    api_key_input = st.text_input(
        "OpenAI API Key (Optional):",
        type="password",
        value=st.session_state.get('openai_api_key', ''),
        help="Optional: Connect your OpenAI API key for live GPT-4o-mini generation, or leave blank to use the built-in offline Gen AI analytical inference engine."
    )
    if api_key_input:
        st.session_state['openai_api_key'] = api_key_input
        st.success(" Open-ended LLM Active")
    else:
        st.info("⚡ Built-in Offline GenAI Engine Active")
        
    st.markdown("---")
    if st.button("🔄 Reset Platform Session", use_container_width=True):
        for k in list(st.session_state.keys()):
            if k not in ['openai_api_key', 'current_step_idx']:
                del st.session_state[k]
        st.session_state['current_step_idx'] = 0
        st.rerun()

# 5. Top Header & Flexible Quick-Nav Bar
top_c1, top_c2 = st.columns([3, 1])
with top_c1:
    st.markdown('<div class="netflix-brand-badge">Full Semester Internship Final Project</div>', unsafe_allow_html=True)
    st.markdown('<h1 class="netflix-brand">NETFLIX CUSTOMER CHURN & RETENTION AI</h1>', unsafe_allow_html=True)
    st.markdown('<div class="netflix-subhead">Designed & Developed by <b>K. Laxmi Narayana</b> (Roll No: <b>23341A4253</b>) • JNTU</div>', unsafe_allow_html=True)
    
with top_c2:
    data_status = " Ready (5,000 Rows)" if 'processed_df' in st.session_state else ("📥 Data Loaded" if 'raw_df' in st.session_state else "⏳ Needs Upload")
    ml_status = " Trained (ROC-AUC ~0.79)" if 'ml_results' in st.session_state else "⏳ Untrained"
    st.markdown(f"""
    <div style="background: rgba(255,255,255,0.04); border: 1px solid rgba(255,255,255,0.08); border-radius: 10px; padding: 10px 14px; font-size: 0.8rem; text-align: right;">
        <span style="color: #9CA3AF;">Pipeline Status:</span> <b>{data_status}</b><br>
        <span style="color: #9CA3AF;">ML Engine:</span> <b>{ml_status}</b>
    </div>
    """, unsafe_allow_html=True)

# Flexible Quick Jump Button Bar
current_idx = st.session_state['current_step_idx']
step_icons = ["📤 1. Ingestion", "🛠️ 2. Processing", "🧠 3. Analytics", "🔮 4. ML Models", "📊 5. Dashboard", "🚀 6. Retention"]

nav_cols = st.columns(6)
for i, col in enumerate(nav_cols):
    with col:
        btn_type = "primary" if i == current_idx else "secondary"
        if st.button(step_icons[i], key=f"nav_btn_{i}", use_container_width=True, type=btn_type):
            st.session_state['current_step_idx'] = i
            st.rerun()

st.markdown("<hr style='border: 0; height: 1px; background: rgba(255,255,255,0.08); margin: 15px 0 25px 0;'>", unsafe_allow_html=True)

# 6. Route to Active Module View
active_step = STEPS[current_idx]

if active_step == "1. Admin Dataset Ingestion":
    render_data_loader()
elif active_step == "2. System Cleaning & Processing":
    render_data_processor()
elif active_step == "3. Analytics & GenAI Insights":
    render_analytics_engine()
elif active_step == "4. ML Churn Predictor":
    render_ml_predictor()
elif active_step == "5. Executive Dashboard":
    render_dashboard()
elif active_step == "6. Retention & Action Hub":
    render_retention_hub()

# 7. Flexible Bottom Step-Switcher
st.markdown("<hr style='border: 0; height: 1px; background: rgba(255,255,255,0.08); margin: 35px 0 20px 0;'>", unsafe_allow_html=True)
b_col1, b_col2, b_col3 = st.columns([1, 2, 1])

with b_col1:
    if current_idx > 0:
        if st.button(f"← Previous: {STEPS[current_idx - 1].split('. ')[1]}", use_container_width=True, key="prev_step_btn"):
            st.session_state['current_step_idx'] = current_idx - 1
            st.rerun()

with b_col2:
    st.markdown(
        f"<div style='text-align: center; color: #6B7280; font-size: 0.85rem; padding-top: 8px;'>"
        f"Stage <b>{current_idx + 1} of 6</b>: {STEPS[current_idx]}</div>",
        unsafe_allow_html=True
    )

with b_col3:
    if current_idx < len(STEPS) - 1:
        if st.button(f"Next: {STEPS[current_idx + 1].split('. ')[1]} →", use_container_width=True, key="next_step_btn"):
            st.session_state['current_step_idx'] = current_idx + 1
            st.rerun()

# 8. Clean Modern Footer
st.markdown(f"""
<div class="netflix-footer">
    <b>Netflix Customer Churn Analysis & Generative AI Retention Platform</b><br>
    Full Semester Internship Final Project in AI & ML • Sole Author: <b>K. Laxmi Narayana</b> (Roll No: <code>23341A4253</code>)<br>
    JNTU • Built with Python, Streamlit, Scikit-Learn, Plotly & Gen AI Architecture
</div>
""", unsafe_allow_html=True)
