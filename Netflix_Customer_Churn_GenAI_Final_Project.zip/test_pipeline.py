import pandas as pd
from modules.data_processor import clean_and_process_data
from modules.ml_predictor import prepare_ml_data, train_and_evaluate_models
from utils.llm_helper import generate_ai_response

def test():
    print("1. Loading raw dataset...")
    df_raw = pd.read_csv("data/netflix_customer_churn_dataset.csv")
    print(f"Raw rows: {len(df_raw)}")

    print("2. Running cleaning & feature engineering...")
    df_proc, logs = clean_and_process_data(df_raw)
    print(f"Processed shape: {df_proc.shape}")

    print("3. Training ML models...")
    X, y = prepare_ml_data(df_proc)
    results, trained_objs, scaler, feat_cols = train_and_evaluate_models(X, y)
    for name, m in results.items():
        print(f"-> {name} | AUC: {m['ROC-AUC']:.4f} | Acc: {m['Accuracy']*100:.2f}% | F1: {m['F1-Score']:.4f}")

    print("4. Testing Gen AI synthesis...")
    ans = generate_ai_response("executive strategic diagnostic", context_df=df_proc)
    print(f"Gen AI returned {len(ans)} characters successfully.")
    print("\nALL PIPELINE TESTS PASSED!")

if __name__ == '__main__':
    test()
